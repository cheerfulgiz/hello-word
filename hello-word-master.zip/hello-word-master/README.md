# hello-word
first timer learning how to 

Hello Hubot,
Happy you found a place to enjoy tacos. 
I speak 4 human languages. I'm learning pyhton, hopefully to communicate with robot species, and maybe one day, enjoy moon tacos in your company.


@16:46 editing this file.

@16:55 editing again
